<template>
  <div class="layout-container">
    <div class="header">
      <header-menu />
    </div>
    <div class="main-container">
      <router-view></router-view>
    </div>
  </div>
</template>

<script setup>
import HeaderMenu from '../components/HeaderMenu.vue'
</script>

<style scoped>
.layout-container {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  background-color: var(--el-bg-color);
}

.header {
  height: 60px;
  background-color: var(--el-bg-color);
  border-bottom: 1px solid var(--el-border-color-light);
  flex-shrink: 0;
}

.main-container {
  flex: 1;
  overflow-y: auto;
  padding: 20px;
  box-sizing: border-box;
  color: var(--el-text-color-primary);
}
</style> 