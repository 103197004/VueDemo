<template>
  <div class="projects-container">
    <div class="projects-header">
      <h2>项目列表</h2>
      <el-button type="primary" @click="handleAdd">
        <el-icon><Plus /></el-icon>新建项目
      </el-button>
    </div>

    <el-table 
      :data="currentPageData" 
      style="width: 100%" 
      v-loading="loading"
      border
    >
      <el-table-column prop="name" label="项目名称" min-width="120">
        <template #default="{ row }">
          <el-link
            type="primary"
            :underline="false"
            @click="handleProjectClick(row)"
            class="project-name-link"
          >
            {{ row.name }}
          </el-link>
        </template>
      </el-table-column>
      <el-table-column prop="description" label="描述" min-width="200" show-overflow-tooltip />
      <el-table-column prop="leader" label="负责人" width="100" />
      <el-table-column prop="status" label="状态" width="100">
        <template #default="{ row }">
          <el-tag :type="getStatusType(row.status)">
            {{ row.status }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="createTime" label="创建时间" width="120" />
      <el-table-column label="操作" width="150" fixed="right">
        <template #default="{ row }">
          <el-button-group>
            <el-button type="primary" link @click="handleEdit(row)">
              编辑
            </el-button>
            <el-button type="danger" link @click="handleDelete(row)">
              删除
            </el-button>
          </el-button-group>
        </template>
      </el-table-column>
    </el-table>

    <div class="pagination-container">
      <el-pagination
        v-model:current-page="currentPage"
        v-model:page-size="pageSize"
        :page-sizes="[10, 20, 30, 50]"
        :total="total"
        layout="total, sizes, prev, pager, next, jumper"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </div>

    <el-dialog
      v-model="dialogVisible"
      :title="dialogType === 'add' ? '新建项目' : '编辑项目'"
      width="500px"
      :close-on-click-modal="false"
      @closed="resetForm"
    >
      <el-form
        ref="formRef"
        :model="projectForm"
        :rules="rules"
        label-width="80px"
      >
        <el-form-item label="项目名称" prop="name">
          <el-input v-model="projectForm.name" placeholder="请输入项目名称" />
        </el-form-item>
        <el-form-item label="项目描述" prop="description">
          <el-input
            v-model="projectForm.description"
            type="textarea"
            :rows="3"
            placeholder="请输入项目描述"
          />
        </el-form-item>
        <el-form-item label="负责人" prop="leader">
          <el-input v-model="projectForm.leader" placeholder="请输入负责人" />
        </el-form-item>
        <el-form-item label="项目状态" prop="status">
          <el-select v-model="projectForm.status" placeholder="请选择状态" style="width: 100%">
            <el-option label="未开始" value="未开始" />
            <el-option label="进行中" value="进行中" />
            <el-option label="已完成" value="已完成" />
            <el-option label="已暂停" value="已暂停" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogVisible = false">取消</el-button>
          <el-button type="primary" @click="submitForm" :loading="submitting">
            确定
          </el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, reactive } from 'vue'
import { Plus } from '@element-plus/icons-vue'
import { ElMessageBox, ElMessage } from 'element-plus'
import { useRouter } from 'vue-router'

const router = useRouter()

// 表格数据相关
const loading = ref(false)
const currentPage = ref(1)
const pageSize = ref(10)
const total = ref(0)
const dialogVisible = ref(false)
const dialogType = ref('add')
const formRef = ref(null)
const submitting = ref(false)

// 表单数据
const projectForm = reactive({
  id: '',
  name: '',
  description: '',
  leader: '',
  status: ''
})

// 表单验证规则
const rules = {
  name: [
    { required: true, message: '请输入项目名称', trigger: 'blur' },
    { min: 2, max: 50, message: '长度在 2 到 50 个字符', trigger: 'blur' }
  ],
  description: [
    { required: true, message: '请输入项目描述', trigger: 'blur' }
  ],
  leader: [
    { required: true, message: '请输入负责人', trigger: 'blur' }
  ],
  status: [
    { required: true, message: '请选择项目状态', trigger: 'change' }
  ]
}

// 生成模拟数据
const projectList = ref(Array.from({ length: 55 }, (_, index) => ({
  id: index + 1,
  name: `项目${index + 1}`,
  description: `这是项目${index + 1}的描述信息，包含了项目的基本情况和主要目标。`,
  leader: ['张三', '李四', '王五', '赵六'][Math.floor(Math.random() * 4)],
  status: ['未开始', '进行中', '已完成', '已暂停'][Math.floor(Math.random() * 4)],
  createTime: new Date(Date.now() - Math.floor(Math.random() * 10000000000)).toLocaleDateString()
})))

// 计算当前页数据
const currentPageData = computed(() => {
  const startIndex = (currentPage.value - 1) * pageSize.value
  const endIndex = startIndex + pageSize.value
  return projectList.value.slice(startIndex, endIndex)
})

// 更新总数
total.value = projectList.value.length

// 状态标签类型
const getStatusType = (status) => {
  const map = {
    '未开始': 'info',
    '进行中': 'primary',
    '已完成': 'success',
    '已暂停': 'warning'
  }
  return map[status] || 'info'
}

// 重置表单
const resetForm = () => {
  if (formRef.value) {
    formRef.value.resetFields()
  }
  Object.assign(projectForm, {
    id: '',
    name: '',
    description: '',
    leader: '',
    status: ''
  })
}

// 新建项目
const handleAdd = () => {
  dialogType.value = 'add'
  dialogVisible.value = true
  resetForm()
}

// 编辑项目
const handleEdit = (row) => {
  dialogType.value = 'edit'
  dialogVisible.value = true
  Object.assign(projectForm, row)
}

// 提交表单
const submitForm = async () => {
  if (!formRef.value) return
  
  await formRef.value.validate((valid, fields) => {
    if (valid) {
      submitting.value = true
      setTimeout(() => {
        if (dialogType.value === 'add') {
          // 新增
          const newProject = {
            id: Date.now(),
            ...projectForm,
            createTime: new Date().toLocaleDateString()
          }
          projectList.value.unshift(newProject)
          ElMessage.success('创建成功')
        } else {
          // 编辑
          const index = projectList.value.findIndex(item => item.id === projectForm.id)
          if (index > -1) {
            projectList.value[index] = { ...projectList.value[index], ...projectForm }
            ElMessage.success('更新成功')
          }
        }
        total.value = projectList.value.length
        dialogVisible.value = false
        submitting.value = false
      }, 500)
    }
  })
}

// 删除项目
const handleDelete = (row) => {
  ElMessageBox.confirm(
    `确定要删除项目"${row.name}"吗？`,
    '警告',
    {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning',
    }
  ).then(() => {
    const index = projectList.value.findIndex(item => item.id === row.id)
    if (index > -1) {
      projectList.value.splice(index, 1)
      total.value = projectList.value.length
      if (currentPageData.value.length === 0 && currentPage.value > 1) {
        currentPage.value--
      }
      ElMessage.success('删除成功')
    }
  })
}

// 分页处理
const handleSizeChange = (val) => {
  pageSize.value = val
  if ((currentPage.value - 1) * pageSize.value >= total.value) {
    currentPage.value = 1
  }
}

const handleCurrentChange = (val) => {
  currentPage.value = val
}

// 跳转到详情页
const handleProjectClick = (row) => {
  router.push(`/projects/${row.id}/info`)
}
</script>

<style scoped>
.projects-container {
  background-color: var(--el-bg-color);
  border-radius: 8px;
  padding: 20px;
}

.projects-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.projects-header h2 {
  margin: 0;
  font-size: 20px;
  color: var(--el-text-color-primary);
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}

:deep(.el-dialog__body) {
  padding-top: 20px;
  padding-bottom: 20px;
}

.project-name-link {
  font-size: 14px;
}

.project-name-link:hover {
  opacity: 0.8;
}

:deep(.dark) .project-name-link {
  color: var(--el-color-primary);
}
</style> 