<template>
  <div class="not-found">
    <div class="content">
      <h1>404</h1>
      <h2>抱歉，页面不存在</h2>
      <p>您访问的页面已被移动、删除或不存在</p>
      <el-button type="primary" @click="goHome">
        返回首页
      </el-button>
      <el-button @click="goBack">
        返回上一页
      </el-button>
    </div>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'

const router = useRouter()

const goHome = () => {
  router.push('/')
}

const goBack = () => {
  router.back()
}
</script>

<style scoped>
.not-found {
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: var(--el-bg-color);
}

.content {
  text-align: center;
  padding: 20px;
}

h1 {
  font-size: 120px;
  margin: 0;
  color: var(--el-color-primary);
  line-height: 1;
}

h2 {
  font-size: 30px;
  margin: 20px 0;
  color: var(--el-text-color-primary);
}

p {
  font-size: 16px;
  color: var(--el-text-color-secondary);
  margin-bottom: 30px;
}

.el-button {
  margin: 0 10px;
}

/* 深色模式适配 */
:deep(.dark) .not-found {
  background-color: var(--el-bg-color-overlay);
}
</style> 