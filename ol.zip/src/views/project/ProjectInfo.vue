<template>
  <el-card class="content-card">
    <template #header>
      <div class="card-header">
        <span>项目信息</span>
        <el-button type="primary" @click="handleEdit">编辑项目</el-button>
      </div>
    </template>
    <el-descriptions :column="2" border>
      <el-descriptions-item label="项目名称">{{ projectInfo.name }}</el-descriptions-item>
      <el-descriptions-item label="创建时间">{{ projectInfo.createTime }}</el-descriptions-item>
      <el-descriptions-item label="负责人">{{ projectInfo.leader }}</el-descriptions-item>
      <el-descriptions-item label="项目状态">
        <el-tag :type="getStatusType(projectInfo.status)">{{ projectInfo.status }}</el-tag>
      </el-descriptions-item>
      <el-descriptions-item label="项目描述" :span="2">
        {{ projectInfo.description }}
      </el-descriptions-item>
    </el-descriptions>
  </el-card>
</template>

<script setup>
import { ElMessage } from 'element-plus'

defineProps({
  projectInfo: {
    type: Object,
    required: true,
    default: () => ({})
  }
})

const getStatusType = (status) => {
  const map = {
    '未开始': 'info',
    '进行中': 'primary',
    '已完成': 'success',
    '已暂停': 'warning'
  }
  return map[status] || 'info'
}

const handleEdit = () => {
  ElMessage.success('点击了编辑按钮')
}
</script>

<style scoped>
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
</style> 