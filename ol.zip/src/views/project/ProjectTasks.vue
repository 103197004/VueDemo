<template>
  <el-card class="content-card">
    <template #header>
      <div class="card-header">
        <span>任务管理</span>
        <el-button type="primary" @click="handleCreateTask">
          <el-icon><Plus /></el-icon>新建任务
        </el-button>
      </div>
    </template>

    <!-- 任务列表 -->
    <el-table
      :data="currentTasksData"
      style="width: 100%"
      v-loading="loading"
    >
      <el-table-column type="index" width="60" label="序号" :index="taskIndexMethod" />
      <el-table-column prop="name" label="任务名称" min-width="180" show-overflow-tooltip>
        <template #default="{ row }">
          <div class="task-name">
            <el-icon><List /></el-icon>
            <span>{{ row.name }}</span>
          </div>
        </template>
      </el-table-column>
      <!-- 其他列保持不变 -->
    </el-table>

    <!-- 分页 -->
    <div class="pagination-container">
      <el-pagination
        v-model:current-page="currentPage"
        v-model:page-size="pageSize"
        :page-sizes="[10, 20, 50, 100]"
        :total="taskList.length"
        layout="total, sizes, prev, pager, next, jumper"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </div>
  </el-card>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus, List } from '@element-plus/icons-vue'

defineProps({
  projectInfo: {
    type: Object,
    required: false,
    default: () => ({})
  }
})

const loading = ref(false)
const currentPage = ref(1)
const pageSize = ref(10)
const taskList = ref([])

// 生成模拟任务数据
const generateMockTasks = (count) => {
  const priorities = ['高', '中', '低']
  const statuses = ['未开始', '进行中', '已完成', '已暂停']
  const assignees = ['张三', '李四', '王五', '赵六', '钱七']
  
  return Array.from({ length: count }, (_, index) => {
    const startDate = new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000)
    const endDate = new Date(startDate.getTime() + Math.random() * 30 * 24 * 60 * 60 * 1000)
    
    return {
      id: index + 1,
      name: `任务${index + 1}`,
      description: `这是任务${index + 1}的详细描述`,
      priority: priorities[Math.floor(Math.random() * priorities.length)],
      assignee: assignees[Math.floor(Math.random() * assignees.length)],
      startTime: startDate.toLocaleString(),
      endTime: endDate.toLocaleString(),
      status: statuses[Math.floor(Math.random() * statuses.length)]
    }
  })
}

// 计算当前页数据
const currentTasksData = computed(() => {
  const startIndex = (currentPage.value - 1) * pageSize.value
  return taskList.value.slice(startIndex, startIndex + pageSize.value)
})

// 初始化数据
onMounted(() => {
  taskList.value = generateMockTasks(85)
})

// 分页方法
const handleSizeChange = (val) => {
  pageSize.value = val
  if ((currentPage.value - 1) * pageSize.value >= taskList.value.length) {
    currentPage.value = 1
  }
}

const handleCurrentChange = (val) => {
  currentPage.value = val
}

// 任务操作方法
const handleCreateTask = () => {
  ElMessage.success('点击了新建任务按钮')
}

const taskIndexMethod = (index) => {
  return (currentPage.value - 1) * pageSize.value + index + 1
}
</script>

<style scoped>
.task-name {
  display: flex;
  align-items: center;
  gap: 8px;
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}
</style> 