<template>
  <div class="project-detail">
    <!-- 头部信息 -->
    <div class="detail-header">
      <div class="header-left">
        <el-button link @click="goBack">
          <el-icon><ArrowLeft /></el-icon>返回
        </el-button>
        <h2>{{ projectInfo.name }}</h2>
        <el-tag :type="getStatusType(projectInfo.status)" class="status-tag">
          {{ projectInfo.status }}
        </el-tag>
      </div>
    </div>

    <!-- 主体内容区 -->
    <div class="detail-content">
      <!-- 左侧菜单 -->
      <div class="left-menu">
        <el-menu
          :default-active="activeMenu"
          class="project-menu"
          router
        >
          <el-menu-item :index="`/projects/${projectId}/info`">
            <el-icon><InfoFilled /></el-icon>
            <span>项目信息</span>
          </el-menu-item>
          <el-menu-item :index="`/projects/${projectId}/upload`">
            <el-icon><Upload /></el-icon>
            <span>文件上传</span>
          </el-menu-item>
          <el-menu-item :index="`/projects/${projectId}/tasks`">
            <el-icon><List /></el-icon>
            <span>任务创建</span>
          </el-menu-item>
          <el-menu-item :index="`/projects/${projectId}/results`">
            <el-icon><DataLine /></el-icon>
            <span>结果预览</span>
          </el-menu-item>
          <el-menu-item :index="`/projects/${projectId}/map`">
            <el-icon><MapLocation /></el-icon>
            <span>地图查看</span>
          </el-menu-item>
        </el-menu>
      </div>

      <!-- 右侧内容区 -->
      <div class="right-content">
        <router-view 
          :project-info="projectInfo"
          v-slot="{ Component }">
          <keep-alive>
            <component :is="Component" />
          </keep-alive>
        </router-view>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed  } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ArrowLeft, InfoFilled, Upload, List, DataLine, MapLocation } from '@element-plus/icons-vue'

const route = useRoute()
const router = useRouter()
const projectId = route.params.id

// 计算当前激活的菜单项
const activeMenu = computed(() => {
  return route.path
})

// 项目信息
const projectInfo = ref({
  id: projectId,
  name: `项目${projectId}`,
  description: '项目描述信息',
  leader: '项目负责人',
  status: '进行中',
  createTime: new Date().toLocaleDateString()
})

// 状态样式
const getStatusType = (status) => {
  const map = {
    '未开始': 'info',
    '进行中': 'primary',
    '已完成': 'success',
    '已暂停': 'warning'
  }
  return map[status] || 'info'
}

// 返回列表
const goBack = () => {
  router.push('/projects')
}
</script>

<style scoped>
.project-detail {
  height: 100%;
  background-color: var(--el-bg-color);
}

.detail-header {
  padding: 20px;
  border-bottom: 1px solid var(--el-border-color-light);
}

.header-left {
  display: flex;
  align-items: center;
  gap: 16px;
}

.header-left h2 {
  margin: 0;
  font-size: 20px;
  color: var(--el-text-color-primary);
}

.detail-content {
  display: flex;
  height: calc(100% - 73px);
}

.left-menu {
  width: 200px;
  border-right: 1px solid var(--el-border-color-light);
  height: 100%;
}

.project-menu {
  border-right: none;
}

.right-content {
  flex: 1;
  padding: 20px;
  overflow-y: auto;
}

:deep(.el-menu-item) {
  display: flex;
  align-items: center;
}

:deep(.el-menu-item .el-icon) {
  margin-right: 8px;
}
</style> 