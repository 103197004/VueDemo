<template>
  <el-card class="content-card">
    <template #header>
      <div class="card-header">
        <span>结果预览</span>
        <el-button-group>
          <el-button type="primary" @click="refreshResults">
            <el-icon><Refresh /></el-icon>刷新
          </el-button>
          <el-button type="success" @click="exportResults">
            <el-icon><Download /></el-icon>导出
          </el-button>
        </el-button-group>
      </div>
    </template>

    <!-- 结果统计 -->
    <div class="result-stats">
      <el-row :gutter="20">
        <el-col :span="6">
          <el-card shadow="hover">
            <template #header>
              <div class="stat-header">
                <span>总任务数</span>
                <el-icon><DataLine /></el-icon>
              </div>
            </template>
            <div class="stat-value">{{ stats.totalTasks }}</div>
          </el-card>
        </el-col>
        <el-col :span="6">
          <el-card shadow="hover">
            <template #header>
              <div class="stat-header">
                <span>已完成</span>
                <el-icon><CircleCheckFilled /></el-icon>
              </div>
            </template>
            <div class="stat-value success">{{ stats.completed }}</div>
          </el-card>
        </el-col>
        <el-col :span="6">
          <el-card shadow="hover">
            <template #header>
              <div class="stat-header">
                <span>处理中</span>
                <el-icon><Loading /></el-icon>
              </div>
            </template>
            <div class="stat-value warning">{{ stats.processing }}</div>
          </el-card>
        </el-col>
        <el-col :span="6">
          <el-card shadow="hover">
            <template #header>
              <div class="stat-header">
                <span>失败</span>
                <el-icon><CircleCloseFilled /></el-icon>
              </div>
            </template>
            <div class="stat-value danger">{{ stats.failed }}</div>
          </el-card>
        </el-col>
      </el-row>
    </div>

    <!-- 结果列表 -->
    <div class="result-list">
      <el-table
        :data="currentPageData"
        style="width: 100%"
        v-loading="loading"
      >
        <el-table-column type="index" width="60" label="序号" :index="indexMethod" />
        <el-table-column prop="taskName" label="任务名称" min-width="180" show-overflow-tooltip />
        <el-table-column prop="processTime" label="处理时间" width="180" />
        <el-table-column prop="status" label="状态" width="100">
          <template #default="{ row }">
            <el-tag :type="getStatusType(row.status)">
              {{ row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="accuracy" label="准确率" width="120">
          <template #default="{ row }">
            <el-progress 
              :percentage="row.accuracy" 
              :status="getProgressStatus(row.accuracy)"
            />
          </template>
        </el-table-column>
        <el-table-column label="操作" width="180" fixed="right">
          <template #default="{ row }">
            <el-button-group>
              <el-button type="primary" link @click="handleViewDetail(row)">
                详情
              </el-button>
              <el-button type="success" link @click="handleDownload(row)">
                下载
              </el-button>
            </el-button-group>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pagination-container">
        <el-pagination
          v-model:current-page="currentPage"
          v-model:page-size="pageSize"
          :page-sizes="[10, 20, 50, 100]"
          :total="resultList.length"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </div>
  </el-card>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { 
  Refresh, 
  Download, 
  DataLine,
  CircleCheckFilled,
  CircleCloseFilled,
  Loading 
} from '@element-plus/icons-vue'

// 基础数据
const loading = ref(false)
const currentPage = ref(1)
const pageSize = ref(10)
const resultList = ref([])

// 统计数据
const stats = ref({
  totalTasks: 0,
  completed: 0,
  processing: 0,
  failed: 0
})

// 生成模拟数据
const generateMockResults = (count) => {
  const statuses = ['已完成', '处理中', '失败']
  return Array.from({ length: count }, (_, index) => {
    const status = statuses[Math.floor(Math.random() * statuses.length)]
    const accuracy = status === '已完成' ? Math.floor(Math.random() * 30) + 70 : 0
    
    return {
      id: index + 1,
      taskName: `任务${index + 1}的处理结果`,
      processTime: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000).toLocaleString(),
      status: status,
      accuracy: accuracy,
      downloadUrl: `#/download/${index + 1}`
    }
  })
}

// 初始化数据
onMounted(() => {
  loading.value = true
  setTimeout(() => {
    resultList.value = generateMockResults(85)
    updateStats()
    loading.value = false
  }, 1000)
})

// 更新统计数据
const updateStats = () => {
  stats.value = {
    totalTasks: resultList.value.length,
    completed: resultList.value.filter(item => item.status === '已完成').length,
    processing: resultList.value.filter(item => item.status === '处理中').length,
    failed: resultList.value.filter(item => item.status === '失败').length
  }
}

// 计算当前页数据
const currentPageData = computed(() => {
  const startIndex = (currentPage.value - 1) * pageSize.value
  return resultList.value.slice(startIndex, startIndex + pageSize.value)
})

// 工具方法
const indexMethod = (index) => {
  return (currentPage.value - 1) * pageSize.value + index + 1
}

const getStatusType = (status) => {
  const map = {
    '已完成': 'success',
    '处理中': 'primary',
    '失败': 'danger'
  }
  return map[status] || 'info'
}

const getProgressStatus = (value) => {
  if (value >= 90) return 'success'
  if (value >= 70) return 'warning'
  return 'exception'
}

// 操作方法
const refreshResults = () => {
  loading.value = true
  setTimeout(() => {
    resultList.value = generateMockResults(85)
    updateStats()
    loading.value = false
    ElMessage.success('刷新成功')
  }, 1000)
}

const exportResults = () => {
  ElMessage.success('开始导出结果')
}

const handleViewDetail = (row) => {
  ElMessage.success(`查看结果详情：${row.taskName}`)
}

const handleDownload = (row) => {
  ElMessage.success(`下载结果：${row.taskName}`)
}

// 分页方法
const handleSizeChange = (val) => {
  pageSize.value = val
  if ((currentPage.value - 1) * pageSize.value >= resultList.value.length) {
    currentPage.value = 1
  }
}

const handleCurrentChange = (val) => {
  currentPage.value = val
}
</script>

<style scoped>
.result-stats {
  margin-bottom: 20px;
}

.stat-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 14px;
}

.stat-value {
  font-size: 24px;
  font-weight: bold;
  text-align: center;
  color: var(--el-text-color-primary);
}

.stat-value.success {
  color: var(--el-color-success);
}

.stat-value.warning {
  color: var(--el-color-warning);
}

.stat-value.danger {
  color: var(--el-color-danger);
}

.pagination-container {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}
</style> 