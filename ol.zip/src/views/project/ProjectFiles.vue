<template>
  <el-card class="content-card">
    <template #header>
      <div class="card-header">
        <span>文件上传</span>
        <el-button 
          type="primary" 
          @click="submitUpload"
          :disabled="uploadFiles?.length === 0"
          :loading="uploading"
        >
          <el-icon><Upload /></el-icon>开始上传
        </el-button>
      </div>
    </template>

    <!-- 上传区域 -->
    <el-upload
      ref="uploadRef"
      class="upload-area"
      drag
      action="#"
      :auto-upload="false"
      :on-change="handleFileChange"
      :on-remove="handleFileRemove"
      :before-upload="beforeUpload"
      multiple
    >
      <el-icon class="el-icon--upload"><UploadFilled /></el-icon>
      <div class="el-upload__text">
        将文件拖到此处，或<em>点击上传</em>
      </div>
      <template #tip>
        <div class="el-upload__tip">
          支持任意类型文件，单个文件不超过500MB
        </div>
      </template>
    </el-upload>

    <!-- 待上传文件列表 -->
    <div v-if="uploadFiles?.length > 0" class="upload-list">
      <div class="upload-list-header">
        <h4>待上传文件 ({{ uploadFiles.length }})</h4>
        <el-button type="danger" link @click="clearUploadFiles">
          清空列表
        </el-button>
      </div>
      <el-table :data="uploadFiles" size="small">
        <!-- 表格列保持不变 -->
      </el-table>
    </div>
  </el-card>
</template>

<script setup>
import { ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Upload, UploadFilled } from '@element-plus/icons-vue'

const uploadRef = ref(null)
const uploadFiles = ref([])
const uploading = ref(false)

const beforeUpload = (file) => {
  const maxSize = 500 * 1024 * 1024 // 500MB
  if (file.size > maxSize) {
    ElMessage.error('文件大小不能超过500MB')
    return false
  }
  return true
}

const handleFileChange = (uploadFile) => {
  uploadFile.status = 'ready'
  uploadFile.percentage = 0
  uploadFiles.value.push(uploadFile)
}

const handleFileRemove = (uploadFile) => {
  const index = uploadFiles.value.findIndex(file => file.uid === uploadFile.uid)
  if (index !== -1) {
    uploadFiles.value.splice(index, 1)
  }
}

const clearUploadFiles = () => {
  ElMessageBox.confirm(
    '确定要清空上传列表吗？',
    '警告',
    {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning',
    }
  ).then(() => {
    uploadFiles.value = []
    if (uploadRef.value) {
      uploadRef.value.clearFiles()
    }
    ElMessage.success('已清空上传列表')
  })
}

const submitUpload = async () => {
  if (!uploadFiles.value?.length) return
  
  uploading.value = true
  try {
    // 模拟上传过程
    await new Promise(resolve => setTimeout(resolve, 2000))
    ElMessage.success('文件上传完成')
    uploadFiles.value = []
    if (uploadRef.value) {
      uploadRef.value.clearFiles()
    }
  } finally {
    uploading.value = false
  }
}
</script>

<style scoped>
.upload-area {
  margin-bottom: 20px;
}

.upload-list {
  margin-top: 20px;
  border-top: 1px solid var(--el-border-color-lighter);
  padding-top: 20px;
}

.upload-list-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
}

.upload-list-header h4 {
  margin: 0;
  font-size: 14px;
  color: var(--el-text-color-primary);
}
</style> 