<template>
  <div class="home-container">
    <!-- 统计卡片 -->
    <el-row :gutter="20" class="stat-row">
      <!-- 文件数统计 -->
      <el-col :span="8" class="stat-col">
        <div class="stat-card blue">
          <div class="stat-content">
            <div class="stat-icon">
              <el-icon><Document /></el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-number">2,345</div>
              <div class="stat-title">文件数</div>
            </div>
            <div class="stat-trend up">
              <span>+12%</span>
              <el-icon><ArrowUp /></el-icon>
            </div>
          </div>
        </div>
      </el-col>

      <!-- 任务数统计 -->
      <el-col :span="8" class="stat-col">
        <div class="stat-card green">
          <div class="stat-content">
            <div class="stat-icon">
              <el-icon><List /></el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-number">1,234</div>
              <div class="stat-title">任务数</div>
            </div>
            <div class="stat-trend up">
              <span>+5%</span>
              <el-icon><ArrowUp /></el-icon>
            </div>
          </div>
        </div>
      </el-col>

      <!-- 完成数统计 -->
      <el-col :span="8" class="stat-col">
        <div class="stat-card orange">
          <div class="stat-content">
            <div class="stat-icon">
              <el-icon><Check /></el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-number">987</div>
              <div class="stat-title">完成数</div>
            </div>
            <div class="stat-trend down">
              <span>-3%</span>
              <el-icon><ArrowDown /></el-icon>
            </div>
          </div>
        </div>
      </el-col>
    </el-row>

    <!-- 图表区域 -->
    <div class="chart-container">
      <el-card class="chart-card">
        <template #header>
          <div class="chart-header">
            <span>数据趋势</span>
            <el-radio-group v-model="chartType" size="small">
              <el-radio-button label="week">最近七天</el-radio-button>
              <el-radio-button label="month">最近30天</el-radio-button>
            </el-radio-group>
          </div>
        </template>
        <div ref="chartRef" class="chart"></div>
      </el-card>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import { Document, List, Check, ArrowUp, ArrowDown } from '@element-plus/icons-vue'
import * as echarts from 'echarts'

// 图表相关
const chartRef = ref(null)
const chartType = ref('week')
let chart = null

// 获取最近7天的日期
const getLastDays = (days) => {
  const result = []
  for (let i = days - 1; i >= 0; i--) {
    const date = new Date()
    date.setDate(date.getDate() - i)
    result.push(date.toLocaleDateString().slice(5)) // 只显示月/日
  }
  return result
}

// 模拟数据
const generateMockData = () => {
  return Array.from({ length: 7 }, () => Math.floor(Math.random() * 1000) + 500)
}

// 初始化图表
const initChart = () => {
  if (chart) {
    chart.dispose()
  }
  
  const chartDom = chartRef.value
  chart = echarts.init(chartDom)
  
  const days = getLastDays(7)
  const option = {
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    legend: {
      data: ['文件数', '任务数', '完成数']
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: days,
      axisLine: {
        lineStyle: {
          color: '#909399'
        }
      }
    },
    yAxis: {
      type: 'value',
      axisLine: {
        lineStyle: {
          color: '#909399'
        }
      },
      splitLine: {
        lineStyle: {
          color: '#ebeef5'
        }
      }
    },
    series: [
      {
        name: '文件数',
        type: 'line',
        smooth: true,
        data: generateMockData(),
        itemStyle: {
          color: '#409EFF'
        },
        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: 'rgba(64,158,255,0.3)' },
            { offset: 1, color: 'rgba(64,158,255,0.1)' }
          ])
        }
      },
      {
        name: '任务数',
        type: 'line',
        smooth: true,
        data: generateMockData(),
        itemStyle: {
          color: '#67C23A'
        },
        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: 'rgba(103,194,58,0.3)' },
            { offset: 1, color: 'rgba(103,194,58,0.1)' }
          ])
        }
      },
      {
        name: '完成数',
        type: 'line',
        smooth: true,
        data: generateMockData(),
        itemStyle: {
          color: '#E6A23C'
        },
        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: 'rgba(230,162,60,0.3)' },
            { offset: 1, color: 'rgba(230,162,60,0.1)' }
          ])
        }
      }
    ]
  }
  
  chart.setOption(option)
}

// 监听窗口大小变化
const handleResize = () => {
  chart && chart.resize()
}

onMounted(() => {
  initChart()
  window.addEventListener('resize', handleResize)
})

onUnmounted(() => {
  window.removeEventListener('resize', handleResize)
  chart && chart.dispose()
})
</script>

<style scoped>
.home-container {
  height: 100%;
  padding: 20px;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
}

.stat-row {
  height: 20vh;
  margin-bottom: 20px;
  flex-shrink: 0;
}

.stat-col {
  height: 100%;
}

.stat-card {
  height: 100%;
  padding: 16px;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.3s;
  position: relative;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  justify-content: center;
  box-sizing: border-box;
}

.stat-card:hover {
  transform: translateY(-5px);
}

/* 蓝色卡片 */
.stat-card.blue {
  background: linear-gradient(135deg, #e6f3ff 0%, #f0f9ff 100%);
}

.stat-card.blue .stat-icon {
  background-color: #409EFF;
  color: #fff;
}

/* 绿色卡片 */
.stat-card.green {
  background: linear-gradient(135deg, #e7f9f0 0%, #f0faf5 100%);
}

.stat-card.green .stat-icon {
  background-color: #67C23A;
  color: #fff;
}

/* 橙色卡片 */
.stat-card.orange {
  background: linear-gradient(135deg, #fff3e6 0%, #fff9f0 100%);
}

.stat-card.orange .stat-icon {
  background-color: #E6A23C;
  color: #fff;
}

.stat-content {
  display: flex;
  align-items: center;
  position: relative;
  height: 100%;
}

.stat-icon {
  width: 56px;
  height: 56px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 20px;
  box-shadow: 0 2px 12px 0 rgba(0,0,0,0.1);
}

.stat-icon :deep(svg) {
  font-size: 28px;
}

.stat-info {
  flex: 1;
}

.stat-number {
  font-size: 28px;
  font-weight: bold;
  color: var(--el-text-color-primary);
  line-height: 1.2;
  margin-bottom: 6px;
}

.stat-title {
  font-size: 15px;
  color: var(--el-text-color-secondary);
}

.stat-trend {
  display: flex;
  align-items: center;
  margin-top: 4px;
}

.stat-trend.up {
  color: #67C23A;
}

.stat-trend.down {
  color: #F56C6C;
}

@media screen and (max-width: 768px) {
  .stat-row {
    height: auto;
  }
  
  .stat-col {
    height: 120px;
    margin-bottom: 20px;
  }
  
  .stat-icon {
    width: 44px;
    height: 44px;
  }
  
  .stat-icon :deep(svg) {
    font-size: 22px;
  }
  
  .stat-number {
    font-size: 22px;
  }
  
  .stat-title {
    font-size: 13px;
  }
}

.chart-container {
  flex: 1;
  min-height: 0;
  display: flex;
  flex-direction: column;
}

.chart-card {
  height: 100%;
  display: flex;
  flex-direction: column;
}

.chart-card :deep(.el-card__body) {
  flex: 1;
  padding: 0 20px 20px;
  overflow: hidden;
}

.chart-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px 0;
}

.chart {
  height: 100%;
  width: 100%;
}

/* 响应式处理 */
@media screen and (max-width: 768px) {
  .home-container {
    padding: 10px;
  }

  .stat-row {
    margin-bottom: 10px;
  }

  .chart-card :deep(.el-card__body) {
    padding: 0 10px 10px;
  }

  .chart-header {
    padding: 10px 0;
  }
}

/* 深色模式适配 */
:deep(.dark) .chart {
  background-color: var(--el-bg-color);
}
</style> 