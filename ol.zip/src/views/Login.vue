<template>
  <div class="login-container">
    <el-card class="login-card">
      <template #header>
        <div class="card-header">
          <h2>用户登录</h2>
        </div>
      </template>
      
      <el-form 
        ref="formRef"
        :model="loginForm"
        :rules="rules"
        label-width="0"
        status-icon
      >
        <el-form-item prop="username">
          <el-input 
            v-model="loginForm.username"
            placeholder="用户名"
            prefix-icon="User"
          />
        </el-form-item>

        <el-form-item prop="password">
          <el-input 
            v-model="loginForm.password"
            type="password"
            placeholder="密码"
            prefix-icon="Lock"
            show-password
            @keyup.enter="handleLogin"
          />
        </el-form-item>

        <el-form-item>
          <el-button 
            type="primary" 
            class="login-button"
            :loading="loading"
            @click="handleLogin"
          >
            登录
          </el-button>
          <el-button 
            type="success" 
            class="register-button"
            @click="goToRegister"
          >
            注册账号
          </el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { User, Lock } from '@element-plus/icons-vue'
import { ElMessage } from 'element-plus'
import { useRouter } from 'vue-router'

const router = useRouter()
const loginFormRef = ref(null)
const loading = ref(false)
const rememberMe = ref(false)

// 默认账号密码
const defaultAccount = {
  username: 'admin',
  password: '123456'
}

const loginForm = reactive({
  username: defaultAccount.username,
  password: defaultAccount.password
})

const loginRules = {
  username: [
    { required: true, message: '请输入用户名', trigger: 'blur' },
    { min: 3, max: 20, message: '长度在 3 到 20 个字符', trigger: 'blur' }
  ],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, max: 20, message: '长度在 6 到 20 个字符', trigger: 'blur' }
  ]
}

// 检查本地存储的登录信息
onMounted(() => {
  const savedAccount = localStorage.getItem('rememberedAccount')
  if (savedAccount) {
    const { username, password } = JSON.parse(savedAccount)
    loginForm.username = username
    loginForm.password = password
    rememberMe.value = true
  }
})

const handleLogin = () => {
  loginFormRef.value?.validate((valid) => {
    if (valid) {
      loading.value = true
      setTimeout(() => {
        loading.value = false
        if (loginForm.username === defaultAccount.username && 
            loginForm.password === defaultAccount.password) {
          // 保存登录信息
          if (rememberMe.value) {
            localStorage.setItem('rememberedAccount', JSON.stringify({
              username: loginForm.username,
              password: loginForm.password
            }))
          } else {
            localStorage.removeItem('rememberedAccount')
          }
          
          localStorage.setItem('token', 'dummy-token')
          ElMessage.success('登录成功')
          router.push('/home')
        } else {
          ElMessage.error('用户名或密码错误')
        }
      }, 1000)
    }
  })
}

// 添加跳转到注册页的方法
const goToRegister = () => {
  router.push('/register')
}
</script>

<style>
/* 重置全局样式 */
html, body, #app {
  margin: 0;
  padding: 0;
  height: 100%;
  width: 100%;
  overflow: hidden;
}
</style>

<style scoped>
.login-container {
  height: 100%;
  width: 100%;
  background-color: #2d3a4b;
  display: flex;
  justify-content: center;
  align-items: center;
  position: fixed;
  top: 0;
  left: 0;
}

.login-box {
  width: 100%;
  max-width: 420px;
  padding: 20px;
  box-sizing: border-box;
}

.login-content {
  background: #fff;
  border-radius: 8px;
  padding: 35px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

.login-title {
  text-align: center;
  margin-bottom: 30px;
}

.login-title h2 {
  color: #409EFF;
  font-weight: bold;
}

.login-form {
  .el-input {
    height: 40px;
    :deep(.el-input__wrapper) {
      background-color: transparent;
    }
  }
}

.login-button {
  width: 100%;
  height: 40px;
}

/* 响应式适配 */
@media screen and (max-width: 768px) {
  .login-box {
    padding: 15px;
  }
}

@media screen and (max-height: 600px) {
  .login-box {
    padding: 10px;
  }
  
  .login-content {
    padding: 10px;
  }
}

.register-button {
  width: 100%;
  margin-top: 10px;
}
</style> 