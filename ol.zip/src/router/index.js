import { createRouter, createWebHistory } from 'vue-router'
import Layout from '../layout/Layout.vue'

const routes = [
  {
    path: '/login',
    name: 'Login',
    component: () => import('../views/Login.vue')
  },
  {
    path: '/register',
    name: 'Register',
    component: () => import('../views/Register.vue')
  },
  {
    path: '/',
    component: Layout,
    redirect: '/home',
    children: [
      {
        path: 'home',
        name: 'Home',
        component: () => import('../views/Home.vue')
      },
      {
        path: 'projects',
        name: 'Projects',
        component: () => import('../views/Projects.vue')
      },
      {
        path: 'projects/:id',
        name: 'ProjectDetail',
        component: () => import('../views/project/ProjectDetail.vue'),
        redirect: to => `/projects/${to.params.id}/info`,
        children: [
          {
            path: 'info',
            name: 'ProjectInfo',
            component: () => import('../views/project/ProjectInfo.vue')
          },
          {
            path: 'upload',
            name: 'ProjectFiles',
            component: () => import('../views/project/ProjectFiles.vue')
          },
          {
            path: 'tasks',
            name: 'ProjectTasks',
            component: () => import('../views/project/ProjectTasks.vue')
          },
          {
            path: 'results',
            name: 'ProjectResults',
            component: () => import('../views/project/ProjectResults.vue')
          },
          {
            path: 'map',
            name: 'ProjectMap',
            component: () => import('../views/project/ProjectMap.vue')
          }
        ]
      }
    ]
  },
  {
    path: '/404',
    name: 'NotFound',
    component: () => import('../views/404.vue')
  },
  {
    path: '/:pathMatch(.*)*',
    redirect: '/404'
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach((to, from, next) => {
  if (to.name?.startsWith('Project') && to.params.id) {
    const isValidProject = checkValidProject(to.params.id)
    if (!isValidProject) {
      next('/404')
      return
    }
  }
  next()
})

function checkValidProject(id) {
  return !isNaN(id) && parseInt(id) > 0 && parseInt(id) <= 100
}

export default router
