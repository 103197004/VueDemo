<template>
  <div class="header-menu-container">
    <div class="logo">
      <h2>Vue Admin</h2>
    </div>
    
    <el-menu
      :default-active="activeMenu"
      mode="horizontal"
      :ellipsis="false"
      class="header-menu"
      router
    >
      <el-menu-item index="/home">
        <el-icon><HomeFilled /></el-icon>
        首页
      </el-menu-item>
      
      <el-menu-item index="/projects">
        <el-icon><Folder /></el-icon>
        项目
      </el-menu-item>
    </el-menu>

    <div class="header-right">
      <el-space>
        <el-tooltip
          :content="isDark ? '切换浅色模式' : '切换深色模式'"
          placement="bottom"
        >
          <div class="theme-switch" @click="toggleTheme">
            <el-icon class="header-icon">
              <Moon v-if="!isDark" />
              <Sunny v-else />
            </el-icon>
          </div>
        </el-tooltip>

        <el-tooltip content="全屏" placement="bottom">
          <div class="fullscreen-switch">
            <el-icon class="header-icon" @click="toggleFullScreen">
              <FullScreen />
            </el-icon>
          </div>
        </el-tooltip>

        <el-dropdown @command="handleCommand">
          <span class="user-dropdown">
            <el-avatar :size="32" src="https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png" />
            <span class="username">Admin</span>
          </span>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item command="logout">
                <el-icon><SwitchButton /></el-icon>退出登录
              </el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </el-space>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useDark, useToggle } from '@vueuse/core'
import { ElMessageBox } from 'element-plus'
import {
  HomeFilled,
  SwitchButton,
  FullScreen,
  Moon,
  Sunny,
  Folder
} from '@element-plus/icons-vue'

const router = useRouter()
const route = useRoute()
const activeMenu = computed(() => route.path)

const isDark = useDark()
const toggleDark = useToggle(isDark)

const toggleTheme = () => {
  toggleDark()
  const html = document.documentElement
  if (isDark.value) {
    html.classList.add('dark')
  } else {
    html.classList.remove('dark')
  }
}

const toggleFullScreen = () => {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen()
  } else {
    if (document.exitFullscreen) {
      document.exitFullscreen()
    }
  }
}

const handleCommand = (command) => {
  if (command === 'logout') {
    ElMessageBox.confirm(
      '确定要退出登录吗？',
      '提示',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      }
    ).then(() => {
      localStorage.removeItem('token')
      router.push('/login')
    }).catch(() => {})
  }
}
</script>

<style>
:root {
  --el-bg-color: var(--el-fill-color-blank);
}

.header-menu-container {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  padding: 0 20px;
  box-sizing: border-box;
}

.logo {
  padding: 0 20px;
  color: #409EFF;
  white-space: nowrap;
}

.header-menu {
  flex: 1;
  border-bottom: none;
  overflow-x: auto;
  white-space: nowrap;
}

.header-menu::-webkit-scrollbar {
  display: none;
}

.header-right {
  padding: 0 20px;
  display: flex;
  align-items: center;
}

.header-icon {
  font-size: 20px;
  cursor: pointer;
  padding: 0 8px;
  color: #606266;
}

.header-icon:hover {
  color: #409EFF;
}

.user-dropdown {
  display: flex;
  align-items: center;
  cursor: pointer;
}

.username {
  margin-left: 8px;
  font-size: 14px;
  color: #606266;
}

:deep(.el-menu--horizontal .el-menu-item),
:deep(.el-menu--horizontal .el-sub-menu__title) {
  height: 60px;
  line-height: 60px;
}

:deep(.el-menu-item .el-icon),
:deep(.el-sub-menu__title .el-icon) {
  margin-right: 5px;
}

:deep(.el-dropdown-menu__item .el-icon) {
  margin-right: 5px;
}

/* 修复菜单样式 */
:deep(.el-menu--horizontal) {
  border-bottom: none !important;
}

:deep(.el-menu--horizontal > .el-menu-item.is-active) {
  border-bottom: 2px solid var(--el-menu-active-color);
}

:deep(.el-menu--horizontal > .el-sub-menu.is-active .el-sub-menu__title) {
  border-bottom: 2px solid var(--el-menu-active-color);
}

/* 修复下拉菜单样式 */
:deep(.el-dropdown-menu) {
  padding: 5px 0;
}

:deep(.el-dropdown-menu__item) {
  display: flex;
  align-items: center;
  padding: 8px 20px;
}
</style> 